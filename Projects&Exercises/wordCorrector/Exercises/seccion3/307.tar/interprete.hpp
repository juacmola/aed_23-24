#include "diccionario.hpp"

#ifndef INTERPRETE_H_INCLUDED
#define INTERPRETE_H_INCLUDED

const string STR_ESPEC="áéíóúÁÉÍÓÚ";

#endif
