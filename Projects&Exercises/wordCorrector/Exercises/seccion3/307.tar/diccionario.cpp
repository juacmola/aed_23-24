#include "diccionario.hpp"



DicPalabras::DicPalabras() {}
